# Angular Multiselect Dropdowns Test

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 6.0.3.

# Any style guides you used for your coding

Follow Boostrap style documentation:
https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css



# Any CSS coding standards

Documentaion of bootstrap CSS:
https://getbootstrap.com/docs/4.4/getting-started/introduction/



# Installation instructions

step 1 : Install Angular CLI global.
step 2: download GIT repository
step 3: NPM install
step 4: NPM START for LOCALHOST environment
step 5: NPM BUILD for production environment


# Description of how the application work 
Region and Country are dynamic values. 
Based on Region selection, country list updates and subsequest country selection , table with selected country details populates below.


# If you ran out of time what else you would have done. 
check properly.. node modules installtion while you do "step 3" in installtion instrctions... you will never run out of time.

