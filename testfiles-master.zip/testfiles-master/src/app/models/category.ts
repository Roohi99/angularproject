export interface Category {
  id: number;
  label: string;
}
