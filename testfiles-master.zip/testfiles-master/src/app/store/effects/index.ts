import { OrderEffects } from './order.effect';

export const EFFECTS = [
  OrderEffects
];
