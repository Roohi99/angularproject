export enum ActionTypes {
  LoadCategories = '[Categories] Load',
  LoadCategoriesSuccess = '[Categories] Load Success',

  LoadProducts = '[Products] Load',
  LoadProductsSuccess = '[Products] Load Success'
}
